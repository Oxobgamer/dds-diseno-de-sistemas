import { Curso } from './curso.model';

describe('Curso', () => {
  it('should create an instance', () => {
    expect(new Curso()).toBeTruthy();
  });
});
