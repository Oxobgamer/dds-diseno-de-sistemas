export class Tema {
	constructor() {
		this.id = 0,
		this.nombre = '',
		this.duracion = 0
	}
	id: number;
	nombre: string;
	duracion: number;
}