import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CursoListComponent } from './components/curso-list/curso-list.component';
import { CursoDetailsComponent } from './components/curso-details/curso-details.component';
import { CursoAddComponent } from './components/curso-add/curso-add.component';

const routes: Routes = [
  { path: '', redirectTo: 'www/cursos', pathMatch: 'full' },
  { path: 'www/cursos', component: CursoListComponent },
  { path: 'www/cursos/algo/:id', component: CursoListComponent },
  { path: 'www/cursos/:id', component: CursoDetailsComponent },
  { path: 'www/add', component: CursoAddComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
